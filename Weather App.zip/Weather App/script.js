let info= document.querySelectorAll(".info")
let button= document.querySelector(".Searcher")
let cityName= document.getElementById("city-name")
let weather= document.getElementById("wthr")
let search= document.querySelector(".search")

function t(){fetch("data.json").then(t=> t.json()).then(s=> {for(let x of s){
 if(x.cityName===search.value){
         info[0].textContent=x.MinimumTemp;
         info[1].textContent=x.MaximumTemp;
         info[2].textContent=x.Humidity;
         weather.textContent=x.weatherType;
         cityName.textContent=search.value
         if(weather.textContent==="Sunny"){
            document.querySelector(".img-shower").src="Images/7084512.png"
        }
        else if(weather.textContent==="Rainy"){
            document.querySelector(".img-shower").src="Images/6142570.png"
        }
        
         
 } }})}

button.addEventListener("click",t)
